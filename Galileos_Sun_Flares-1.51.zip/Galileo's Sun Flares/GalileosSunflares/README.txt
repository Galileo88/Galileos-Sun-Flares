This is an addon for Scatterer's sun flare feature. It Includes THE BEST sunflares you can get! BIG shout out to Blackrack for making Scatterer which allowed for a rather incompetent modder to contribute to the awesome KSP community! 

TO INSTALL:
Choose the Sun flare that you would like (Alpha, Bravo, Ect.) and place the inclosed files in GameData> scatterer> sunflare
overwrite all files 

This mods is licensed by Creative Commons Attribution-NonCommercial-NoDerivs 